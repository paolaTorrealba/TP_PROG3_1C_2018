<?php

require 'vendor/autoload.php';
require_once 'datos/AccesoDatos.php';
require_once 'api/loginApi.php';
require_once 'api/usuarioApi.php';
require_once 'api/pedidoApi.php';
require_once 'api/encuestaApi.php';
require_once 'api/mesaApi.php';
require_once 'entidades/login.php';
require_once 'entidades/usuario.php';
require_once 'entidades/pedido.php';
require_once 'entidades/encuesta.php';
require_once 'entidades/mesa.php';
require_once 'middleware/MWparaAutentificar.php';
require_once 'middleware/MWparaCORS.php';


$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

$app = new \Slim\App(["settings" => $config]);

$app->post('/login', \loginApi::class. ':obtenerLogin');      
/*
 GET  /usuario/         :cargarUno - Socio
 POST /usuario/eliminar :borrarUno - Socio 
 PUT  /usuario/         :modificarUno - Socio 
 GET  /usuario/         :traerTodos - Usuario
 */
$app->group('/usuario', function () {      
  $this->post('/', \usuarioApi::class . ':cargarUno')->add(\MWparaAutentificar::class . ':VerificarSocio');
  $this->post('/eliminar', \usuarioApi::class . ':borrarUno')->add(\MWparaAutentificar::class . ':VerificarSocio');	
	$this->put('/', \usuarioApi::class . ':modificarUno')->add(\MWparaAutentificar::class . ':VerificarSocio');  
  $this->get('/', \usuarioApi::class . ':traerTodos')->add(\MWparaAutentificar::class . ':VerificarUsuario'); 

})->add(\MWparaCORS::class . ':HabilitarCORS8080');

/*
  POST /pedido/           :cargarUno  - Mozo
  GET  /pedido/           :traerTodos
  GET  /pedido/cancelados :traerCancelados
  POST /pedido/paraServir :pedidoListoParaServir
  POST /pedido/servido    :pedidoServido
  POST /pedido/aPagar     :pedidoAPagar
  POST /pedido/cerrado    :cerrarPedido
*/

$app->group('/pedido', function () {  
  $this->post('/', \pedidoApi::class . ':cargarUno')->add(\MWparaAutentificar::class . ':VerificarMozo');
  $this->get('/', \pedidoApi::class. ':traerTodos')->add(\MWparaAutentificar::class . ':VerificarUsuario');
  $this->get('/cancelados', \pedidoApi::class. ':traerCancelados')->add(\MWparaAutentificar::class . ':VerificarUsuario'); 
  $this->post('/paraServir', \pedidoApi::class.':pedidoListoParaServir')->add(\MWparaAutentificar::class.':VerificarMozo');
  $this->post('/servido', \pedidoApi::class. ':pedidoServido')->add(\MWparaAutentificar::class . ':VerificarMozo');
  $this->post('/aPagar', \pedidoApi::class. ':pedidoAPagar')->add(\MWparaAutentificar::class . ':VerificarMozo');
  $this->post('/cerrado', \pedidoApi::class. ':cerrarPedido')->add(\MWparaAutentificar::class . ':VerificarSocio');        

})->add(\MWparaCORS::class . ':HabilitarCORS8080');

 /*
 POST /encuesta/       :cargarUno
 GET  /encuesta/       :traerTodos
*/

$app->group('/encuesta', function () {
  $this->post('/', \encuestaApi::class . ':cargarUno')->add(\MWparaAutentificar::class . ':VerificarMozo');
  $this->get('/', \encuestaApi::class. ':traerTodos')->add(\MWparaAutentificar::class . ':VerificarUsuario');
         
})->add(\MWparaCORS::class . ':HabilitarCORS8080');
      
 /*
 GET /mesa/       :traerTodos
 GET /mesa/       :traerPorEstado
*/

$app->group('/mesa', function () {
  $this->get('/', \mesaApi::class. ':traerTodos')->add(\MWparaAutentificar::class . ':VerificarUsuario');
  $this->get('/estados', \mesaApi::class. ':traerPorEstado')->add(\MWparaAutentificar::class . ':VerificarUsuario');
          
})->add(\MWparaCORS::class . ':HabilitarCORS8080');




/* Para ver el tema de permisos*/
/*
$app->group('', function () {
    $this->group('/usuario', function(){
        $this->get('/', \usuarioApi::class. ':traerTodos')->add(\MWparaAutentificar::class . ':VerificarPerfilSocio');    
        $this->get('/', \usuarioApi::class. ':traerUno')->add(\MWparaAutentificar::class . ':VerificarPerfilSocio');    
        $this->post('/', \usuarioApi::class . ':cargarUno')->add(\MWparaAutentificar::class . ':VerificarUsuario');
        $this->delete('/', \usuarioApi::class . ':borrarUno')->add(\MWparaAutentificar::class . ':VerificarUsuario');
        $this->put('/', \usuarioApi::class . ':modificarUno')->add(\MWparaAutentificar::class . ':VerificarUsuario');      
    })->add(\MWparaAutentificar::class . ':VerificarPerfilSocio');
*/

$app->run();

?>