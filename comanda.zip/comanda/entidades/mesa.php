<?php
use \Firebase\JWT\JWT;
require_once "./datos/AccesoDatos.php";

// OPERACIONES 
//-traerTodos()
//-traerPorid($id)
//-traerPorEstado($estado)
  
  
class mesa{
    public $id;
    public $estado; 


    public static function traerTodos(){
        $pdo = AccesoDatos::dameUnObjetoAcceso();
        $sql = $pdo->RetornarConsulta("SELECT * from  mesa");
        $sql->execute();

        $resultado = $sql->fetchall(PDO::FETCH_CLASS, "mesa");   

        return $resultado;
    }

    public static function traerPorid($id){

        $pdo = AccesoDatos::dameUnObjetoAcceso();
        $sql = $pdo->RetornarConsulta("SELECT * FROM  mesa WHERE id=:id");
        $sql->bindValue(':id',$id, PDO::PARAM_INT);
        $sql->execute();

        $resultado = $sql->fetchall(PDO::FETCH_CLASS, "mesa");
        
        return $resultado;
    }

    public static function traerPorEstado($estado){

        $pdo = AccesoDatos::dameUnObjetoAcceso();
        $sql = $pdo->RetornarConsulta("SELECT * FROM  mesa WHERE estado=:estado");
        $sql->bindValue(':estado',$estado, PDO::PARAM_STR);
        $sql->execute();

        $resultado = $sql->fetchall(PDO::FETCH_CLASS, "mesa");
        
        return $resultado;
    }


}
?>