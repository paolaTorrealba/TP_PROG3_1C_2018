<?php
require_once './vendor/autoload.php';
require_once './entidades/mesa.php';

//OPERACIONES
//-traerTodos($request, $response, $args)
//-traerPorEstado($request, $response, $args)
       
class mesaApi{
    
    public function traerTodos($request, $response, $args){
        $mesa = mesa::traerTodos();
        $newResponse = $response->withJson($mesa, 200);
        return $newResponse;
    }

    public function traerPorEstado($request, $response, $args){
        $arrayDeParametros = $request->getParsedBody();
        $mesa = mesa::traerPorEstado($arrayDeParametros);
        $response = $response->withJson($mesa, 200);
        return $response;
    }
}
?>